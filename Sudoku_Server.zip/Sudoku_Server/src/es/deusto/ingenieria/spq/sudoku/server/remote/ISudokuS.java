package es.deusto.ingenieria.spq.sudoku.server.remote;


import java.rmi.RemoteException;
import java.rmi.Remote;

import es.deusto.ingenieria.spq.sudoku.server.data.*;

/**
 * Remote Fa�ade
 * @author 
 *
 */
public interface ISudokuS extends Remote {
	public void recibirPartida(Partida partida) throws RemoteException;
	public Usuario inicioSesion(String nick) throws RemoteException;
	public Usuario registrar(String nick, String pass) throws RemoteException;
}
