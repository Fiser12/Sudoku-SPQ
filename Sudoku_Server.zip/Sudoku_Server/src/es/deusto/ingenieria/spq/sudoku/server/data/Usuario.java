package es.deusto.ingenieria.spq.sudoku.server.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.jdo.annotations.Join;
import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;

@PersistenceCapable
public class Usuario implements Serializable 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	String nick;
	String pass;
	
	@Persistent(mappedBy="usuario", dependentElement="true")
	@Join
	private List<Partida> partidas = new ArrayList<Partida>();
	public Usuario() {
		
	}
	public Usuario(String nick, String pass) {
		this.nick = nick;
		this.pass = pass;
	}
	public String getNick() {
		return nick;
	}
	public void setNick(String nick) {
		this.nick = nick;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	
	public void addPartida(Partida partida) {
		partidas.add(partida);
	}
}
