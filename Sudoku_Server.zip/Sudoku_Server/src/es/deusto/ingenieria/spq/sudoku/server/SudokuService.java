package es.deusto.ingenieria.spq.sudoku.server;

import es.deusto.ingenieria.spq.sudoku.server.data.*;

public class SudokuService
{
	public synchronized void recibirPartida(Partida partida)
	{
		new DAOSudokus().recibirPartida(partida);
	}
	
	public synchronized Usuario inicioSesion(String nick)
	{
		return new DAOSudokus().inicioSesion(nick);
	}
	
	public synchronized Usuario registrar(String nick, String pass)
	{
		return new DAOSudokus().registrar(nick, pass);
	}
}
