package es.deusto.ingenieria.spq.sudoku.server;

import javax.jdo.Extent;
import javax.jdo.JDOHelper;
import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;
import javax.jdo.Transaction;

import es.deusto.ingenieria.spq.sudoku.server.data.*;

public class DAOSudokus {
	public void recibirPartida(Partida partida) {
		// Load Persistence Manager Factory - referencing the Persistence Unit defined in persistence.xml
		PersistenceManagerFactory pmf = JDOHelper.getPersistenceManagerFactory("datanucleus.properties");
		// Persistence Manager
		PersistenceManager pm = null;
		//Transaction to group DB operations
		Transaction tx = null;		
		try {
			//Get the Persistence Manager
			pm = pmf.getPersistenceManager();
			//Obtain the current transaction
			tx = pm.currentTransaction();		
			//Start the transaction

			tx.begin();
			Extent<Usuario> extent = pm.getExtent(Usuario.class, true);
			for (Usuario u : extent) {
				if(u.getNick().equals(partida.getUsuario().getNick())){
					Partida partida2 = new Partida(partida.getDificultad(), partida.getTiempo(), u);
					u.addPartida(partida2);
					pm.makePersistent(partida2);
				}
			}

			//End the transaction
			tx.commit();			

		} catch (Exception ex) {
//					System.err.println(" $ Error storing objects in the DB: " + ex.getMessage());
//					ex.printStackTrace();
		} finally {
			if (tx != null && tx.isActive()) {
				tx.rollback();
			}

			if (pm != null && !pm.isClosed()) {
				pm.close();
				// ATTENTION -  Datanucleus detects that the objects in memory were changed and they are flushed to DB
			}
		}
	}
	
	public Usuario inicioSesion(String nick)
	{
		Usuario usuario = null;
		// Load Persistence Manager Factory - referencing the Persistence Unit defined in persistence.xml
		PersistenceManagerFactory pmf = JDOHelper.getPersistenceManagerFactory("datanucleus.properties");
		// Persistence Manager
		PersistenceManager pm = null;
		//Transaction to group DB operations
		Transaction tx = null;
		try {
			pm = pmf.getPersistenceManager();
			//Obtain the current transaction
			tx = pm.currentTransaction();	
			tx.begin();

			Extent<Usuario> extent = pm.getExtent(Usuario.class, true);
			for (Usuario u : extent) {
				if (u.getNick().equals(nick)) {
					usuario = new Usuario(nick, u.getPass());
				}
			}

			tx.commit();
		} catch (Exception ex) {
			System.out.println("# Error getting Extent: " + ex.getMessage());
		} finally {
			if (tx.isActive()) {
				tx.rollback();
			}

			pm.close();
		}
		return usuario;
	}
	
	public Usuario registrar(String nick, String pass)
	{
		Usuario usuario = new Usuario(nick, pass);
		// Load Persistence Manager Factory - referencing the Persistence Unit defined in persistence.xml
		PersistenceManagerFactory pmf = JDOHelper.getPersistenceManagerFactory("datanucleus.properties");
		// Persistence Manager
		PersistenceManager pm = null;
		//Transaction to group DB operations
		Transaction tx = null;		
		try {
			//Get the Persistence Manager
			pm = pmf.getPersistenceManager();
			//Obtain the current transaction
			tx = pm.currentTransaction();		
			//Start the transaction

			tx.begin();
			
			Extent<Usuario> extent = pm.getExtent(Usuario.class, true);
			for (Usuario u : extent) {
				if (u.getNick().equals(nick)) {
					tx.commit();
					return null;
				}
			}
			
			pm.makePersistent(usuario);

			//End the transaction
			tx.commit();			

		} catch (Exception ex) {
//					System.err.println(" $ Error storing objects in the DB: " + ex.getMessage());
//					ex.printStackTrace();
		} finally {
			if (tx != null && tx.isActive()) {
				tx.rollback();
			}

			if (pm != null && !pm.isClosed()) {
				pm.close();
				// ATTENTION -  Datanucleus detects that the objects in memory were changed and they are flushed to DB
			}
		}
		return usuario;
	}
	
	public static void main(String[] args) {
		System.out.println("Datanucleus + JDO example");
		System.out.println("=========================");
	
		//Create objects -  objects in memory
		Usuario usuario1 = new Usuario("spq1", "spq1");
		Usuario usuario2 = new Usuario("spq2", "spq2");
		
		// Load Persistence Manager Factory - referencing the Persistence Unit defined in persistence.xml
		PersistenceManagerFactory pmf = JDOHelper.getPersistenceManagerFactory("datanucleus.properties");
		// Persistence Manager
		PersistenceManager pm = null;
		//Transaction to group DB operations
		Transaction tx = null;		
		try {
			System.out.println("- Store objects in the DB");			
			//Get the Persistence Manager
			pm = pmf.getPersistenceManager();
			//Obtain the current transaction
			tx = pm.currentTransaction();		
			//Start the transaction

			tx.begin();
			pm.makePersistent(usuario1);
			pm.makePersistent(usuario2);

			//End the transaction
			tx.commit();			

		} catch (Exception ex) {
//			System.err.println(" $ Error storing objects in the DB: " + ex.getMessage());
//			ex.printStackTrace();
		} finally {
			if (tx != null && tx.isActive()) {
				tx.rollback();
			}

			if (pm != null && !pm.isClosed()) {
				pm.close();
				// ATTENTION -  Datanucleus detects that the objects in memory were changed and they are flushed to DB
			}
		}
	}
}
