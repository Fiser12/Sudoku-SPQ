package es.deusto.ingenieria.spq.sudoku.server.remote;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import es.deusto.ingenieria.spq.sudoku.server.SudokuService;
import es.deusto.ingenieria.spq.sudoku.server.data.*;

public class SudokuS extends UnicastRemoteObject implements ISudokuS {

	private static final long serialVersionUID = 1L;
	private SudokuService sudServ;
	
	public SudokuS(SudokuService sudServ) throws RemoteException {
		super();
		this.sudServ = sudServ;
		// TODO Auto-generated constructor stub
	}

	@Override
	public void recibirPartida(Partida partida)
			throws RemoteException {
		sudServ.recibirPartida(partida);
		System.out.println ("* New partida on the server ... " + 
			partida.getDificultad() + " and " + 
			partida.getTiempo() + " and " + 
			partida.getUsuario().getNick());
		// TODO Auto-generated method stub
		
	}

	@Override
	public Usuario inicioSesion(String nick) throws RemoteException {
		return sudServ.inicioSesion(nick);
	}

	@Override
	public Usuario registrar(String nick, String pass) throws RemoteException {
		return sudServ.registrar(nick, pass);
	}

}
