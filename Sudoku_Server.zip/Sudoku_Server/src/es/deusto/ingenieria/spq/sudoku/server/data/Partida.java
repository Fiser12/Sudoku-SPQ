package es.deusto.ingenieria.spq.sudoku.server.data;

import java.io.Serializable;

import javax.jdo.annotations.PersistenceCapable;

@PersistenceCapable
public class Partida implements Serializable 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	int dificultad;
	float tiempo;
	Usuario usuario;
	public Partida() {
		
	}
	
	public Partida(int dificultad, float tiempo, Usuario usuario) {
		this.dificultad = dificultad;
		this.tiempo = tiempo;
		this.usuario = usuario;
	}

	public int getDificultad() {
		return dificultad;
	}
	public void setDificultad(int dificultad) {
		this.dificultad = dificultad;
	}
	public float getTiempo() {
		return tiempo;
	}
	public void setTiempo(float tiempo) {
		this.tiempo = tiempo;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
	
}
