package es.deusto.ingenieria.spq.sudoku.server;

import java.rmi.Naming;
import java.rmi.RMISecurityManager;

import es.deusto.ingenieria.spq.sudoku.server.remote.*;

@SuppressWarnings("deprecation")
public class SudokuManagerServer {

	public static void main(String[] args) {
		if (args.length != 3) {
			System.exit(0);
		}

		if (System.getSecurityManager() == null) {
			System.setSecurityManager(new RMISecurityManager());
		}

		String name = "//" + args[0] + ":" + args[1] + "/" + args[2];

		try {
			SudokuService sudServ = new SudokuService();
			
			ISudokuS sudService = new SudokuS(sudServ);
			Naming.rebind(name, sudService);
			System.out.println("* Cancion Admin Service '" + name + "' active and waiting...");
		} catch (Exception e) {
			System.err.println("$ CancionManager exception: " + e.getMessage());
			e.printStackTrace();
		}
	}
}